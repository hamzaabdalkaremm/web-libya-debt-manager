
import React from 'react';
import { Debt, DebtType, DebtStatus } from '../types';

interface DebtCardProps {
  debt: Debt;
  onToggleStatus: (id: string) => void;
  onDelete: (id: string) => void;
}

export const DebtCard: React.FC<DebtCardProps> = ({ debt, onToggleStatus, onDelete }) => {
  const isLent = debt.type === DebtType.LENT;
  const isPaid = debt.status === DebtStatus.PAID;

  return (
    <div className={`p-4 mb-3 rounded-2xl border transition-all ${isPaid ? 'bg-gray-100 opacity-60' : 'bg-white shadow-sm border-gray-100'}`}>
      <div className="flex justify-between items-start mb-2">
        <div>
          <h3 className="font-bold text-lg text-gray-800">{debt.contactName}</h3>
          <p className="text-xs text-gray-500">{debt.date}</p>
        </div>
        <div className="text-left">
          <span className={`text-xl font-bold ${isLent ? 'text-green-600' : 'text-red-600'}`}>
            {isLent ? '+' : '-'} {debt.amount.toLocaleString()} د.ل
          </span>
          <p className={`text-[10px] font-bold px-2 py-0.5 rounded-full mt-1 inline-block ${isLent ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
            {isLent ? 'لي عنده' : 'عليّ ليه'}
          </p>
        </div>
      </div>
      
      {debt.notes && (
        <p className="text-sm text-gray-600 mb-3 bg-gray-50 p-2 rounded-lg italic">
          "{debt.notes}"
        </p>
      )}

      <div className="flex gap-2">
        <button 
          onClick={() => onToggleStatus(debt.id)}
          className={`flex-1 py-2 rounded-xl text-sm font-bold transition-colors ${
            isPaid 
            ? 'bg-blue-100 text-blue-700' 
            : 'bg-indigo-600 text-white active:bg-indigo-700'
          }`}
        >
          {isPaid ? 'تراجع عن السداد' : 'تم السداد'}
        </button>
        <button 
          onClick={() => onDelete(debt.id)}
          className="px-4 py-2 bg-gray-100 text-gray-500 rounded-xl text-sm hover:bg-red-50 hover:text-red-500 transition-colors"
        >
          حذف
        </button>
      </div>
    </div>
  );
};
