
import React from 'react';
import { DashboardStats } from '../types';

interface DashboardProps {
  stats: DashboardStats;
}

export const Dashboard: React.FC<DashboardProps> = ({ stats }) => {
  return (
    <div className="grid grid-cols-2 gap-4 mb-6">
      <div className="bg-white p-4 rounded-3xl shadow-sm border border-green-50">
        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mb-2">
          <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 11l5-5m0 0l5 5m-5-5v12" />
          </svg>
        </div>
        <p className="text-xs text-gray-500 font-medium">لي عند الناس</p>
        <h2 className="text-xl font-extrabold text-green-700">{stats.totalLent.toLocaleString()} <span className="text-xs">د.ل</span></h2>
      </div>

      <div className="bg-white p-4 rounded-3xl shadow-sm border border-red-50">
        <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mb-2">
          <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 13l-5 5m0 0l-5-5m5 5V6" />
          </svg>
        </div>
        <p className="text-xs text-gray-500 font-medium">عليّ للناس</p>
        <h2 className="text-xl font-extrabold text-red-700">{stats.totalBorrowed.toLocaleString()} <span className="text-xs">د.ل</span></h2>
      </div>

      <div className="col-span-2 bg-indigo-600 p-5 rounded-3xl shadow-lg shadow-indigo-100 flex justify-between items-center text-white">
        <div>
          <p className="text-indigo-100 text-sm">الرصيد الصافي</p>
          <h2 className="text-2xl font-black">{stats.balance.toLocaleString()} د.ل</h2>
        </div>
        <div className="bg-white/20 p-3 rounded-2xl">
          <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8c-1.657 0-3 1.343-3 3s1.343 3 3 3 3-1.343 3-3-1.343-3-3-3z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2z" />
          </svg>
        </div>
      </div>
    </div>
  );
};
