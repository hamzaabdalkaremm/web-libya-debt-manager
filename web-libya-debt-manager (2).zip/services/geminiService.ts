
import { GoogleGenAI } from "@google/genai";
import { Debt, DebtType } from "../types";

export const getFinancialAdvice = async (debts: Debt[]): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const lentDebts = debts.filter(d => d.type === DebtType.LENT && d.status === 'PENDING');
  const borrowedDebts = debts.filter(d => d.type === DebtType.BORROWED && d.status === 'PENDING');
  
  const prompt = `
    أنت مستشار مالي ذكي تعمل لدى شركة "ويب ليبيا" (Web Libya).
    إليك قائمة الديون الحالية للمستخدم:
    الديون التي له عند الآخرين: ${lentDebts.map(d => `${d.contactName}: ${d.amount} د.ل`).join(', ')}
    الديون التي عليه للآخرين: ${borrowedDebts.map(d => `${d.contactName}: ${d.amount} د.ل`).join(', ')}
    
    بناءً على هذه البيانات، قدم نصيحة مالية مختصرة ومشجعة باللهجة الليبية أو العربية الفصحى البسيطة حول كيفية إدارة هذه الديون. ركز على الأولويات.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "عذراً، لم أستطع تحليل البيانات حالياً.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "حدث خطأ أثناء الاتصال بالذكاء الاصطناعي.";
  }
};
